import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import { createRoot } from 'react-dom/client';
import LikeButton from './LikeButton';
import 'mapbox-gl/dist/mapbox-gl.css';
import type { LngLatLike } from 'mapbox-gl';
import { debounce } from 'lodash';

interface Place {
  id: string;
  name: string;
  category: string;
  description: string;
  coordinates: [number, number];
  image: string;
}

const Globe = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markers = useRef<mapboxgl.Marker[]>([]);
  const [isZooming, setIsZooming] = useState(false);
  const animationFrameId = useRef<number>();

  useEffect(() => {
    if (!mapContainer.current) return;

    mapboxgl.accessToken = 'pk.eyJ1IjoidmlydHUzIiwiYSI6ImNtNzZ5bGFqZTEwNXIyb3E4dTltZ2wwMnIifQ.2cMdPHQWdxI9KiA80YAajA';
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/dark-v11',
      projection: 'globe',
      zoom: 1.5,
      center: [30, 15],
      pitch: 45,
      maxZoom: 18,
      minZoom: 1,
      renderWorldCopies: true,
      trackResize: true,
      fadeDuration: 0,
      antialias: true,
      localIdeographFontFamily: "'Noto Sans', 'Noto Sans CJK SC', sans-serif"
    });

    (window as any).currentMap = map.current;

    const samplePlaces: Place[] = [
      {
        id: '1',
        name: 'Eiffel Tower',
        category: 'Landmarks',
        description: 'Iconic iron lattice tower on the Champ de Mars in Paris',
        coordinates: [2.2945, 48.8584],
        image: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?w=400'
      },
      {
        id: '2',
        name: 'Taj Mahal',
        category: 'Historical',
        description: 'An ivory-white marble mausoleum on the right bank of the river Yamuna in Agra',
        coordinates: [78.0421, 27.1751],
        image: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?w=400'
      },
      {
        id: '3',
        name: 'Santorini',
        category: 'Destinations',
        description: 'Beautiful island in the Aegean Sea, known for its white-washed buildings',
        coordinates: [25.3960, 36.3932],
        image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=400'
      }
    ];

    const createMarkers = () => {
      markers.current.forEach(marker => marker.remove());
      markers.current = [];

      const zoom = map.current?.getZoom() || 0;
      if (zoom < 2) return;

      samplePlaces.forEach(place => {
        const popup = new mapboxgl.Popup({ 
          offset: 25,
          maxWidth: '300px',
          closeButton: true,
          closeOnClick: true,
          closeOnMove: false,
        }).setHTML(`
          <div class="p-4 max-w-sm">
            <img src="${place.image}" alt="${place.name}" class="w-full h-48 object-cover rounded-lg mb-3"/>
            <h3 class="text-lg font-semibold">${place.name}</h3>
            <p class="text-sm text-gray-600">${place.category}</p>
            <p class="text-sm mt-2">${place.description}</p>
            <div id="like-button-${place.id}" class="mt-3"></div>
          </div>
        `);

        const marker = new mapboxgl.Marker({
          element: createMarkerElement(),
        })
          .setLngLat(place.coordinates as LngLatLike)
          .setPopup(popup);

        marker.addTo(map.current!);
        markers.current.push(marker);

        popup.on('open', () => {
          const container = document.getElementById(`like-button-${place.id}`);
          if (container) {
            const root = createRoot(container);
            root.render(<LikeButton placeId={place.id} />);
          }
        });
      });
    };

    const createMarkerElement = () => {
      const el = document.createElement('div');
      el.className = 'custom-marker';
      el.style.width = '24px';
      el.style.height = '24px';
      el.style.backgroundImage = 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%23ffffff\'%3E%3Cpath d=\'M12 0c-4.198 0-8 3.403-8 7.602 0 4.198 3.469 9.21 8 16.398 4.531-7.188 8-12.2 8-16.398 0-4.199-3.801-7.602-8-7.602zm0 11c-1.657 0-3-1.343-3-3s1.343-3 3-3 3 1.343 3 3-1.343 3-3 3z\'/%3E%3C/svg%3E")';
      el.style.backgroundSize = 'contain';
      el.style.backgroundRepeat = 'no-repeat';
      el.style.cursor = 'pointer';
      return el;
    };

    const debouncedCreateMarkers = debounce(createMarkers, 500);

    const handleZoom = debounce(() => {
      setIsZooming(true);
      debouncedCreateMarkers();
    }, 100);

    map.current.on('zoom', handleZoom);

    map.current.on('zoomend', () => {
      setIsZooming(false);
    });

    map.current.addControl(
      new mapboxgl.NavigationControl({
        visualizePitch: true,
        showZoom: true,
        showCompass: true,
      }),
      'top-right'
    );

    map.current.addControl(
      new mapboxgl.ScaleControl({
        maxWidth: 100,
        unit: 'metric'
      }),
      'bottom-left'
    );

    map.current.scrollZoom.setWheelZoomRate(0.3);
    map.current.scrollZoom.setZoomRate(0.3);

    map.current.on('style.load', () => {
      if (!map.current) return;
      
      map.current.setFog({
        color: 'rgb(15, 23, 42)',
        'high-color': 'rgb(15, 23, 42)',
        'horizon-blend': 0.2,
        'space-color': 'rgb(15, 23, 42)',
        'star-intensity': 0.6
      });

      map.current.setTerrain({ source: 'mapbox-dem', exaggeration: 1.2 });
      
      createMarkers();
    });

    const rotationSpeed = 360;
    let userInteracting = false;
    let lastTime = 0;
    
    function spinGlobe(time: number) {
      if (!map.current || userInteracting || isZooming) {
        animationFrameId.current = requestAnimationFrame(spinGlobe);
        return;
      }
      
      if (!lastTime) lastTime = time;
      const timeDiff = time - lastTime;
      lastTime = time;
      
      const center = map.current.getCenter();
      center.lng -= (360 / rotationSpeed) * (timeDiff / 1000);
      
      map.current.easeTo({
        center,
        duration: 0,
        easing: (t) => t
      });
      
      animationFrameId.current = requestAnimationFrame(spinGlobe);
    }

    map.current.on('mousedown', () => {
      userInteracting = true;
      lastTime = 0;
    });
    
    map.current.on('mouseup', () => {
      userInteracting = false;
      lastTime = 0;
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
      requestAnimationFrame(spinGlobe);
    });

    animationFrameId.current = requestAnimationFrame(spinGlobe);

    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
      handleZoom.cancel();
      debouncedCreateMarkers.cancel();
      markers.current.forEach(marker => marker.remove());
      if (map.current) {
        map.current.remove();
        (window as any).currentMap = null;
      }
    };
  }, [isZooming]);

  return (
    <div className="relative w-full h-[60vh] min-h-[500px]">
      <div ref={mapContainer} className="absolute inset-0 rounded-2xl overflow-hidden" />
      <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/20 to-background pointer-events-none" />
    </div>
  );
};

export default Globe;
