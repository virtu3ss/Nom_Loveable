
import { Button } from "@/components/ui/button";
import { MapPin, Coffee, UtensilsCrossed, Beer, Building2 } from "lucide-react";

const categories = [
  { name: "Places", icon: MapPin },
  { name: "Restaurants", icon: UtensilsCrossed },
  { name: "Cafés", icon: Coffee },
  { name: "Bars", icon: Beer },
  { name: "Near Me", icon: Building2 },
];

const CategoryFilters = () => {
  return (
    <div className="flex flex-wrap gap-2 justify-center">
      {categories.map(({ name, icon: Icon }) => (
        <Button
          key={name}
          variant="ghost"
          className="h-10 px-4 py-2 bg-white/5 hover:bg-white/10 text-white/90 rounded-full border border-white/10 transition-all duration-300"
        >
          <Icon className="w-4 h-4 mr-2" />
          {name}
        </Button>
      ))}
    </div>
  );
};

export default CategoryFilters;
