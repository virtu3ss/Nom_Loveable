
import { useState, useEffect } from "react";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface LikeButtonProps {
  placeId: string;
  initialIsLiked?: boolean;
  onLikeChange?: (isLiked: boolean) => void;
}

const LikeButton = ({ placeId, initialIsLiked = false, onLikeChange }: LikeButtonProps) => {
  const [isLiked, setIsLiked] = useState(initialIsLiked);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkIfLiked();
  }, [placeId]);

  const checkIfLiked = async () => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return;

    try {
      const { data, error } = await supabase
        .from('likes')
        .select('id')
        .eq('place_id', placeId)
        .eq('user_id', session.session.user.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setIsLiked(!!data);
    } catch (error) {
      console.error('Error checking like status:', error);
    }
  };

  const toggleLike = async () => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) {
      toast({
        title: "Authentication required",
        description: "Please sign in to like places",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      if (isLiked) {
        const { error } = await supabase
          .from('likes')
          .delete()
          .eq('place_id', placeId)
          .eq('user_id', session.session.user.id);

        if (error) throw error;
        toast({
          title: "Success",
          description: "Removed from favorites"
        });
      } else {
        const { error } = await supabase
          .from('likes')
          .insert([
            {
              place_id: placeId,
              user_id: session.session.user.id
            }
          ]);

        if (error) throw error;
        toast({
          title: "Success",
          description: "Added to favorites"
        });
      }

      setIsLiked(!isLiked);
      if (onLikeChange) {
        onLikeChange(!isLiked);
      }
    } catch (error) {
      console.error('Error toggling like:', error);
      toast({
        title: "Error",
        description: "Failed to update favorite status",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      disabled={isLoading}
      onClick={toggleLike}
      className={`${isLiked ? 'text-red-500 hover:text-red-700' : 'text-gray-500 hover:text-gray-700'}`}
    >
      <Heart className={`h-5 w-5 ${isLiked ? 'fill-current' : ''}`} />
    </Button>
  );
};

export default LikeButton;
