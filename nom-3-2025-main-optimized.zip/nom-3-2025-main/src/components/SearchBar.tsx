
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import mapboxgl from 'mapbox-gl';
import { supabase } from '@/integrations/supabase/client';

const SearchBar = () => {
  const [query, setQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsSearching(true);
    try {
      // First, try to find places in our database
      const { data: dbPlaces, error: dbError } = await supabase
        .from('places')
        .select('*')
        .ilike('name', `%${query}%`)
        .limit(5);

      if (dbError) throw dbError;

      if (dbPlaces && dbPlaces.length > 0) {
        // If we found places in our DB, use those
        const firstPlace = dbPlaces[0];
        const map = (window as any).currentMap;
        
        if (map) {
          map.flyTo({
            center: [firstPlace.longitude, firstPlace.latitude],
            zoom: 12,
            duration: 2000,
            essential: true
          });
        }
        return;
      }

      // If no results in DB, use Mapbox geocoding as fallback
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(
          query
        )}.json?access_token=${mapboxgl.accessToken}`
      );

      const data = await response.json();
      if (data.features && data.features.length > 0) {
        const [lng, lat] = data.features[0].center;
        const map = (window as any).currentMap;
        
        if (map) {
          map.flyTo({
            center: [lng, lat],
            zoom: 12,
            duration: 2000,
            essential: true
          });
        }

        // Trigger Firecrawl to find information about this location
        try {
          const { data: crawlData, error: crawlError } = await supabase.functions.invoke('scrape-places', {
            body: { query: data.features[0].place_name }
          });

          if (crawlError) {
            console.error('Crawl error:', crawlError);
          } else if (crawlData) {
            toast({
              title: "Finding more information",
              description: "We're discovering details about this location.",
              duration: 3000,
            });
          }
        } catch (crawlError) {
          console.error('Error during crawl:', crawlError);
        }
      }
    } catch (error) {
      console.error("Search error:", error);
      toast({
        title: "Search Error",
        description: "Unable to find the location. Please try again.",
        variant: "destructive",
        duration: 3000,
      });
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <form onSubmit={handleSearch} className="w-full max-w-3xl mx-auto">
      <div className="relative flex items-center">
        <Input
          type="text"
          placeholder="Discover your next favorite spot..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full h-14 pl-12 pr-28 text-lg bg-white/10 border-white/20 rounded-full focus:ring-primary/50 focus:border-primary/50 transition-all duration-300"
        />
        <Search className="absolute left-4 w-6 h-6 text-white/60" />
        <Button
          type="submit"
          disabled={isSearching}
          className="absolute right-2 bg-primary hover:bg-primary/90 text-white rounded-full px-6 h-10"
        >
          {isSearching ? "Searching..." : "Search"}
        </Button>
      </div>
    </form>
  );
};

export default SearchBar;
