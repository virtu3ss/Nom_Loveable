import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Database } from "@/integrations/supabase/types";
import { useToast } from "@/components/ui/use-toast";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

type Place = Database['public']['Tables']['places']['Row'];
type Like = Database['public']['Tables']['likes']['Row'];

const Favorites = () => {
  const [favorites, setFavorites] = useState<(Place & { like_id: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchFavorites();
  }, []);

  const fetchFavorites = async () => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) {
      navigate("/auth");
      return;
    }

    try {
      const { data, error } = await supabase
        .from('likes')
        .select(`
          *,
          places:places (*)
        `)
        .eq('user_id', session.session.user.id);

      if (error) throw error;

      const formattedFavorites = data.map(item => ({
        ...item.places,
        like_id: item.id
      }));

      setFavorites(formattedFavorites);
    } catch (error) {
      console.error('Error fetching favorites:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to fetch favorites"
      });
    } finally {
      setLoading(false);
    }
  };

  const unlikePlace = async (placeId: string, likeId: string) => {
    try {
      const { error } = await supabase
        .from('likes')
        .delete()
        .eq('id', likeId);

      if (error) throw error;

      setFavorites(prev => prev.filter(fav => fav.id !== placeId));
      toast({
        title: "Success",
        description: "Place removed from favorites"
      });
    } catch (error) {
      console.error('Error removing favorite:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to remove from favorites"
      });
    }
  };

  const handleViewOnMap = (longitude: number, latitude: number) => {
    const map = (window as any).currentMap;
    if (map) {
      map.flyTo({
        center: [longitude, latitude],
        zoom: 15,
        duration: 2000
      });
      navigate('/');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-8 text-primary">My Favorites</h1>
        
        {favorites.length === 0 ? (
          <div className="text-center py-12">
            <Heart className="mx-auto h-12 w-12 text-gray-400 mb-4 fill-current" />
            <p className="text-xl text-gray-600">No favorites yet</p>
            <Button
              variant="ghost"
              className="mt-4"
              onClick={() => navigate('/')}
            >
              Discover Places
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map((place) => (
              <Card key={place.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle>{place.name}</CardTitle>
                  <CardDescription>{place.category}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    {place.description || 'No description available'}
                  </p>
                  <div className="flex justify-between items-center">
                    <Button
                      variant="outline"
                      onClick={() => handleViewOnMap(Number(place.longitude), Number(place.latitude))}
                    >
                      View on Map
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => unlikePlace(place.id, place.like_id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Heart className="h-5 w-5 fill-current" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Favorites;
