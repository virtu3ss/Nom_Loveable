
// Improved NOM Web Scraper - Supabase Edge Function

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

serve(async (req) => {
    try {
        // Ensure request is a POST request
        if (req.method !== "POST") {
            return new Response(JSON.stringify({ error: "Only POST requests are allowed" }), { status: 405 });
        }

        // Parse request body
        const { query, limit = 10, offset = 0 } = await req.json();
        if (!query) {
            return new Response(JSON.stringify({ error: "Query parameter is required" }), { status: 400 });
        }

        // Load API Keys securely
        const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY");
        const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
        const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

        if (!FIRECRAWL_API_KEY || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
            return new Response(JSON.stringify({ error: "Missing API keys" }), { status: 500 });
        }

        // Fetch data from FirecrawlApp (pagination included)
        const firecrawlResponse = await fetch("https://api.firecrawl.app/search", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${FIRECRAWL_API_KEY}`
            },
            body: JSON.stringify({ query, limit, offset })
        });

        const result = await firecrawlResponse.json();
        
        // Handle Firecrawl errors
        if (!result.success) {
            return new Response(JSON.stringify({ error: "Scraping failed", details: result }), { status: 500 });
        }

        // Store results in Supabase
        const supabaseResponse = await fetch(`${SUPABASE_URL}/rest/v1/places`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "apikey": SUPABASE_SERVICE_ROLE_KEY,
                "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
            },
            body: JSON.stringify(result.data)
        });

        if (!supabaseResponse.ok) {
            return new Response(JSON.stringify({ error: "Failed to save data to Supabase" }), { status: 500 });
        }

        return new Response(JSON.stringify({ success: true, data: result.data }), { status: 200 });

    } catch (error) {
        return new Response(JSON.stringify({ error: "Unexpected server error", details: error.message }), { status: 500 });
    }
});
